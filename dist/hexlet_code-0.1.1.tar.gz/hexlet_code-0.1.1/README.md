### Hexlet tests and linter status:
[![Actions Status](https://github.com/Svarojichh/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Svarojichh/python-project-49/actions)
### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/30cede35bb03df53d814/maintainability)](https://codeclimate.com/github/Svarojichh/python-project-49/maintainability)
