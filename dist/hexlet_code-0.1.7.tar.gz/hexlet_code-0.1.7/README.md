### Hexlet tests and linter status:
[![Actions Status](https://github.com/Svarojichh/python-project-49/workflows/hexlet-check/badge.svg)](https://github.com/Svarojichh/python-project-49/actions)
### Maintainability Badge:
[![Maintainability](https://api.codeclimate.com/v1/badges/30cede35bb03df53d814/maintainability)](https://codeclimate.com/github/Svarojichh/python-project-49/maintainability)
### test game brain-even:
[![asciicast](https://asciinema.org/a/b91O766RpbQxD2cN9X1fn4QZL.svg)](https://asciinema.org/a/b91O766RpbQxD2cN9X1fn4QZL)
### test game brain-calc:
[![asciicast](https://asciinema.org/a/wD8sDLQWp8JWzs7T4BVD3P6f6.svg)](https://asciinema.org/a/wD8sDLQWp8JWzs7T4BVD3P6f6)
### test game brain-gcd:
[![asciicast](https://asciinema.org/a/gdpfHuzlCGYBbVOv4PQ5GZn7l.svg)](https://asciinema.org/a/gdpfHuzlCGYBbVOv4PQ5GZn7l)
### test game brain-progression:
[![asciicast](https://asciinema.org/a/M9o5xquSuUj7bP1YcZJB1QL8x.svg)](https://asciinema.org/a/M9o5xquSuUj7bP1YcZJB1QL8x)
